//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

import UIKit

class ___FILEBASENAMEASIDENTIFIER___LogicManager: NSObject {
    
    private let classViewModel: ___FILEBASENAMEASIDENTIFIER___ViewModel
    
    override init() {
        self.classViewModel = ___FILEBASENAMEASIDENTIFIER___ViewModel()
        super.init()
    }
    
}
