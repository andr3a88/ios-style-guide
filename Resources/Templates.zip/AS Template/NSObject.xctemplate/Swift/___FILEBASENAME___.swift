//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

import Foundation

class ___FILEBASENAMEASIDENTIFIER___: NSObject {
    
//MARK: - Property -


//MARK: - Lifecycle -

    override init() {
    <# init property #>
    }


//MARK: - Public -


//MARK: - Private  -



}
