//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

#import <Foundation/Foundation.h>

@interface ___FILEBASENAMEASIDENTIFIER___ : NSObject

/**
 * gets singleton object.
 * @return singleton
 */
+ (___FILEBASENAMEASIDENTIFIER___*)sharedInstance;

@end
