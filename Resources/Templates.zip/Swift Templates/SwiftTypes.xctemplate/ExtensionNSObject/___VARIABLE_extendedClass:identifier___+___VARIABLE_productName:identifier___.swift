//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

import Foundation

/** ___FILEBASENAMEASIDENTIFIER___ Extends ___VARIABLE_extendedClass:identifier___

*/
extension ___VARIABLE_extendedClass:identifier___ {
    

}
