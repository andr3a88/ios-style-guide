//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

import UIKit
import XCTest

/** ___FILEBASENAMEASIDENTIFIER___ Class

*/
class ___FILEBASENAMEASIDENTIFIER___ : XCTestCase {

    func testExample() {
        // This is an example of a functional test case.
        XCTAssertTrue(true, "Pass")
    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock() {
            // Put the code you want to measure the time of here.
        }
    }

    // MARK: - Setup
    override func setUp() {
        super.setUp()
        // Put Setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
}
