//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

#import "___FILEBASENAME___.h"

@implementation ___FILEBASENAMEASIDENTIFIER___

#pragma mark - Lifecycle

- (instancetype)init
{
    self = [super init];
    if (self) {
		<# Init property#>
    }
    return self;
}


#pragma mark - Public


#pragma mark - Private

@end
